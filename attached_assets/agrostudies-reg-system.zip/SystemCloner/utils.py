import os
import uuid
from datetime import datetime
from werkzeug.utils import secure_filename
from flask import current_app

ALLOWED_EXTENSIONS = {'pdf', 'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and \
           filename.lower().split('.')[-1] in ALLOWED_EXTENSIONS

def get_upload_dir():
    upload_dir = os.path.join(current_app.root_path, 'uploads')
    if not os.path.exists(upload_dir):
        os.makedirs(upload_dir)
    return upload_dir

def save_document(file, candidate_id):
    if file and allowed_file(file.filename):
        # Create candidate directory if it doesn't exist
        candidate_dir = os.path.join(get_upload_dir(), str(candidate_id))
        if not os.path.exists(candidate_dir):
            os.makedirs(candidate_dir)
        
        # Generate unique filename
        original_filename = secure_filename(file.filename)
        ext = original_filename.rsplit('.', 1)[1].lower()
        unique_filename = f"{uuid.uuid4().hex}.{ext}"
        
        # Save the file
        file_path = os.path.join(candidate_dir, unique_filename)
        file.save(file_path)
        
        return file_path
    
    return None

def get_status_color(status):
    """Return Bootstrap color class based on candidate status"""
    status_colors = {
        'Draft': 'secondary',
        'New': 'info',
        'Fixed': 'primary',
        'Rejected': 'danger',
        'Approved': 'success',
        'Quit': 'warning'
    }
    return status_colors.get(status, 'secondary')

def calculate_age(birthdate):
    today = datetime.today()
    age = today.year - birthdate.year - ((today.month, today.day) < (birthdate.month, birthdate.day))
    return age
