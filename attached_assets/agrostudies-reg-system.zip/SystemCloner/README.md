# AgroStudies Registration System

A web-based registration system for agricultural students applying to TESDA and Agrostudies programs.

## Features

- Authentication system for administrators and coordinators
- Document verification system for student applications
- Candidate management with status tracking
- Age verification and qualification validation
- Document upload and management system
- Responsive design for all screen sizes

## Technology Stack

- **Backend**: Flask (Python)
- **Database**: PostgreSQL (online) / SQLite (offline)
- **Frontend**: HTML, CSS, JavaScript, Bootstrap
- **Authentication**: Flask-Login
- **Forms**: Flask-WTF

## Installation

1. Clone this repository
```bash
git clone https://github.com/yourusername/agrostudies-registration.git
cd agrostudies-registration
```

2. Install dependencies
```bash
pip install -r dependencies.txt
```

3. Choose your database option:

### Option A: Run with PostgreSQL (Online)
```bash
# Create a .env file with the following variables
DATABASE_URL=postgresql://username:password@localhost:5432/agrostudies
```

### Option B: Run with SQLite (Offline)
No configuration needed! The application will automatically use SQLite if no DATABASE_URL is set.

4. Run the application
```bash
python main.py
```

The first time you run the application, it will:
- Create the database tables automatically
- Create a default admin user (email: admin@agrostudies.com, password: admin123)
- Create a default coordinator user (email: coordinator@agrostudies.com, password: coordinator123)

## Project Structure

- `app.py`: Application factory and configuration
- `main.py`: Application entry point
- `models.py`: Database models
- `forms.py`: Form definitions
- `routes.py`: API endpoints and page routes
- `utils.py`: Utility functions
- `templates/`: HTML templates
- `static/`: Static files (CSS, JS, images)

## License

[MIT](https://choosealicense.com/licenses/mit/)