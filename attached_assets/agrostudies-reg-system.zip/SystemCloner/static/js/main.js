document.addEventListener('DOMContentLoaded', function() {
    // Format all date fields to use the required format
    const dateFields = document.querySelectorAll('input[type="date"]');
    dateFields.forEach(field => {
        field.addEventListener('change', function() {
            if (this.value) {
                const date = new Date(this.value);
                const day = String(date.getDate()).padStart(2, '0');
                const month = String(date.getMonth() + 1).padStart(2, '0');
                const year = date.getFullYear();
                this.setAttribute('data-formatted-date', `${day}/${month}/${year}`);
            }
        });
    });

    // Age verification for date of birth field
    const dobField = document.getElementById('date_of_birth');
    if (dobField) {
        dobField.addEventListener('change', function() {
            if (this.value) {
                const dob = new Date(this.value);
                const today = new Date();
                let age = today.getFullYear() - dob.getFullYear();
                const monthDiff = today.getMonth() - dob.getMonth();
                
                if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
                    age--;
                }
                
                if (age > 29) {
                    alert('Warning: Candidate must not be more than 29 years old.');
                }
            }
        });
    }

    // File upload preview
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', function(e) {
            const fileInfo = this.parentElement.querySelector('.file-info');
            if (fileInfo) {
                if (this.files.length > 0) {
                    const file = this.files[0];
                    const fileSize = (file.size / 1024).toFixed(2);
                    fileInfo.textContent = `Selected: ${file.name} (${fileSize} KB)`;
                    fileInfo.style.color = fileSize > 4000 ? 'red' : '#6c757d';
                } else {
                    fileInfo.textContent = '';
                }
            }
        });
    });

    // Passport number validation
    const passportField = document.getElementById('passport_number');
    const confirmPassportField = document.getElementById('confirm_passport');
    
    if (passportField && confirmPassportField) {
        // Check for number zero instead of letter O
        passportField.addEventListener('blur', function() {
            if (this.value.includes('0')) {
                alert('Warning: Please ensure you are using the letter "O" rather than the digit "0" (zero) in the passport number if appropriate.');
            }
        });
        
        // Confirm passport validation
        confirmPassportField.addEventListener('blur', function() {
            if (this.value && passportField.value && this.value !== passportField.value) {
                alert('Error: Passport numbers do not match.');
                this.value = '';
                this.focus();
            }
        });
    }

    // Name validation
    const firstNameField = document.getElementById('first_name');
    const confirmFirstNameField = document.getElementById('confirm_first_name');
    const surnameField = document.getElementById('surname');
    const confirmSurnameField = document.getElementById('confirm_surname');
    
    if (firstNameField && confirmFirstNameField) {
        confirmFirstNameField.addEventListener('blur', function() {
            if (this.value && firstNameField.value && this.value !== firstNameField.value) {
                alert('Error: First names do not match.');
                this.value = '';
                this.focus();
            }
        });
    }
    
    if (surnameField && confirmSurnameField) {
        confirmSurnameField.addEventListener('blur', function() {
            if (this.value && surnameField.value && this.value !== surnameField.value) {
                alert('Error: Surnames do not match.');
                this.value = '';
                this.focus();
            }
        });
    }

    // Form submission
    const form = document.querySelector('form.registration-form');
    if (form) {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let hasErrors = false;
            
            requiredFields.forEach(field => {
                if (!field.value) {
                    hasErrors = true;
                    field.classList.add('is-invalid');
                } else {
                    field.classList.remove('is-invalid');
                }
            });
            
            if (hasErrors) {
                e.preventDefault();
                alert('Please fill in all required fields before submitting.');
                window.scrollTo(0, 0);
            }
        });
    }

    // Initialize tooltips
    const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
    if (tooltipTriggerList.length) {
        [...tooltipTriggerList].map(tooltipTriggerEl => new bootstrap.Tooltip(tooltipTriggerEl));
    }

    // Delete confirmation
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this candidate? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });
});

// Status update function for admin
function updateStatus(candidateId, newStatus) {
    if (confirm(`Are you sure you want to change the status to ${newStatus}?`)) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/candidates/${candidateId}/status/${newStatus}`;
        
        // Add CSRF token
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        const csrfInput = document.createElement('input');
        csrfInput.type = 'hidden';
        csrfInput.name = 'csrf_token';
        csrfInput.value = csrfToken;
        form.appendChild(csrfInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}
