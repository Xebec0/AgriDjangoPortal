$(document).ready(function() {
    // Simple DataTables initialization
    if ($('#candidates-table').length) {
        $('#candidates-table').DataTable({
            responsive: true,
            ordering: true,
            searching: false, // We use our own search form
            pageLength: 10,
            lengthMenu: [10, 25, 50, 100],
            order: [[3, 'asc'], [1, 'asc']] // Sort by Status then Name
        });
    }
});
