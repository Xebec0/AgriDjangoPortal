document.addEventListener('DOMContentLoaded', function() {
    // Custom form validation
    (() => {
        'use strict';

        // Fetch all forms that need validation
        const forms = document.querySelectorAll('.needs-validation');

        // Loop over them and prevent submission
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }

                form.classList.add('was-validated');
            }, false);
        });
    })();

    // Additional validation for age
    const validateAge = (dobInput) => {
        if (!dobInput) return true;
        
        const dob = new Date(dobInput.value);
        const today = new Date();
        let age = today.getFullYear() - dob.getFullYear();
        const monthDiff = today.getMonth() - dob.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
            age--;
        }
        
        if (age > 29) {
            dobInput.setCustomValidity('Candidate must not be more than 29 years old.');
            return false;
        } else {
            dobInput.setCustomValidity('');
            return true;
        }
    };

    // Document type validation
    const validateDocumentType = (fileInput, allowedTypes) => {
        if (!fileInput || !fileInput.files || fileInput.files.length === 0) return true;
        
        const file = fileInput.files[0];
        const fileName = file.name.toLowerCase();
        const fileExt = fileName.split('.').pop();
        
        if (!allowedTypes.includes(fileExt)) {
            fileInput.setCustomValidity(`Only ${allowedTypes.join(', ')} files are allowed.`);
            return false;
        } else {
            fileInput.setCustomValidity('');
            return true;
        }
    };

    // File size validation
    const validateFileSize = (fileInput, maxSizeKB) => {
        if (!fileInput || !fileInput.files || fileInput.files.length === 0) return true;
        
        const file = fileInput.files[0];
        const fileSize = file.size / 1024; // KB
        
        if (fileSize > maxSizeKB) {
            fileInput.setCustomValidity(`File size must not exceed ${maxSizeKB}KB.`);
            return false;
        } else {
            fileInput.setCustomValidity('');
            return true;
        }
    };

    // Attach validation to date of birth field
    const dobInput = document.getElementById('date_of_birth');
    if (dobInput) {
        dobInput.addEventListener('change', () => validateAge(dobInput));
    }

    // Attach validation to file inputs
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', () => {
            const allowedTypes = ['jpg', 'jpeg', 'png', 'pdf'];
            const maxSizeKB = 4000; // 4MB
            
            validateDocumentType(input, allowedTypes);
            validateFileSize(input, maxSizeKB);
        });
    });

    // Add passport number validation (letter O vs number 0)
    const passportInput = document.getElementById('passport_number');
    if (passportInput) {
        passportInput.addEventListener('input', function() {
            // Replace any visual feedback
            const feedbackElement = this.nextElementSibling;
            if (feedbackElement && feedbackElement.classList.contains('invalid-feedback')) {
                feedbackElement.textContent = '';
            }
            
            // Check for zeros that might be mistaken for letter O
            if (/0/.test(this.value)) {
                this.classList.add('is-warning');
                
                // Add or update warning message
                if (!feedbackElement || !feedbackElement.classList.contains('invalid-feedback')) {
                    const warning = document.createElement('div');
                    warning.classList.add('invalid-feedback');
                    warning.style.color = '#ffc107';
                    warning.textContent = 'Make sure you use the letter "O" rather than the digit "0" where appropriate.';
                    this.parentNode.appendChild(warning);
                } else {
                    feedbackElement.textContent = 'Make sure you use the letter "O" rather than the digit "0" where appropriate.';
                    feedbackElement.style.color = '#ffc107';
                }
            } else {
                this.classList.remove('is-warning');
            }
        });
    }
});
