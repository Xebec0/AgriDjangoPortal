import os
from app import create_app

# For local development, explicitly set SQLite
if __name__ == "__main__" and not os.environ.get("DATABASE_URL"):
    os.environ["DATABASE_URL"] = "sqlite:///agrostudies.db"

app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
