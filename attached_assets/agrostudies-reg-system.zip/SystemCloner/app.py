import os
import logging
from datetime import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_wtf.csrf import CSRFProtect
from sqlalchemy.orm import DeclarativeBase

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Base(DeclarativeBase):
    pass

# Initialize extensions
db = SQLAlchemy(model_class=Base)
login_manager = LoginManager()
csrf = CSRFProtect()

def create_app():
    # Create Flask app
    app = Flask(__name__)
    
    # Configure app
    app.config['SECRET_KEY'] = os.environ.get("SESSION_SECRET", "agrostudies_secret_key")
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get("DATABASE_URL", "sqlite:///agrostudies.db")
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Set max upload size to 5MB
    app.config['MAX_CONTENT_LENGTH'] = 5 * 1024 * 1024
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    csrf.init_app(app)
    
    # Configure login
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'
    
    # Template filters
    @app.template_filter('format_date')
    def format_date(value, format='%d/%m/%Y'):
        if value:
            return value.strftime(format)
        return ""
    
    @app.context_processor
    def inject_now():
        return {'now': datetime.utcnow()}
    
    with app.app_context():
        # Import models and create tables
        from models import User, Candidate, Document
        db.create_all()
        
        # Check if default users exist, if not create them
        from models import User, UserRole
        from werkzeug.security import generate_password_hash
        
        # Create admin user if it doesn't exist
        if not User.query.filter_by(email='admin@agrostudies.com').first():
            admin = User(
                name='Admin',
                email='admin@agrostudies.com',
                password_hash=generate_password_hash('admin123'),
                role=UserRole.ADMIN
            )
            db.session.add(admin)
            db.session.commit()
            logger.info("Created default admin user")
            
        # Create coordinator user if it doesn't exist
        if not User.query.filter_by(email='coordinator@agrostudies.com').first():
            coordinator = User(
                name='Coordinator',
                email='coordinator@agrostudies.com',
                password_hash=generate_password_hash('coordinator123'),
                role=UserRole.COORDINATOR
            )
            db.session.add(coordinator)
            db.session.commit()
            logger.info("Created default coordinator user")
        
        # Register blueprints
        from routes import auth_bp, main_bp, candidate_bp
        app.register_blueprint(auth_bp)
        app.register_blueprint(main_bp)
        app.register_blueprint(candidate_bp)
        
        return app
