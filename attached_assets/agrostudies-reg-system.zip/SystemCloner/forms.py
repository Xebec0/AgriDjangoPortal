from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import (
    StringField, PasswordField, DateField, SelectField, BooleanField,
    SubmitField, ValidationError
)
from wtforms.validators import DataRequired, Email, Length, EqualTo, Optional
from datetime import datetime, date
from models import User, Candidate, DocumentType

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('Remember Me')
    submit = SubmitField('Log In')

class CandidateForm(FlaskForm):
    # University selection
    university = SelectField('University', validators=[DataRequired()], 
                            choices=[('DILG-E', 'DILG-E'), ('TESDA', 'TESDA')])
    
    # Passport details
    passport_number = StringField('Passport', validators=[DataRequired(), Length(min=6, max=20)])
    confirm_passport = StringField('Confirm Passport', validators=[
        DataRequired(), 
        EqualTo('passport_number', message='Passport numbers must match')
    ])
    passport_issue_date = DateField('Date of issue', format='%d/%m/%Y', validators=[DataRequired()])
    passport_expiry_date = DateField('Date of expiry', format='%d/%m/%Y', validators=[DataRequired()])
    
    # Personal details
    first_name = StringField('First name', validators=[DataRequired(), Length(max=50)])
    confirm_first_name = StringField('Confirm first name', validators=[
        DataRequired(), 
        EqualTo('first_name', message='First names must match')
    ])
    surname = StringField('Surname', validators=[DataRequired(), Length(max=50)])
    confirm_surname = StringField('Confirm surname', validators=[
        DataRequired(), 
        EqualTo('surname', message='Surnames must match')
    ])
    father_name = StringField('Name of father', validators=[DataRequired(), Length(max=100)])
    mother_name = StringField('Name of mother', validators=[DataRequired(), Length(max=100)])
    date_of_birth = DateField('Date of birth', format='%d/%m/%Y', validators=[DataRequired()])
    
    # Dropdown selections
    country_of_birth = SelectField('Country of birth', validators=[DataRequired()], 
                                 choices=[('Philippines', 'Philippines')])
    nationality = SelectField('Nationality', validators=[DataRequired()], 
                            choices=[('Filipino', 'Filipino')])
    religion = SelectField('Religion', validators=[DataRequired()], 
                         choices=[('Catholic', 'Catholic'), ('Christian', 'Christian'), 
                                 ('Muslim', 'Muslim'), ('Other', 'Other')])
    family_status = SelectField('Family status', validators=[DataRequired()], 
                              choices=[('Single', 'Single'), ('Married', 'Married'), 
                                      ('Divorced', 'Divorced'), ('Widowed', 'Widowed')])
    gender = SelectField('Gender', validators=[DataRequired()], 
                       choices=[('Male', 'Male'), ('Female', 'Female')])
    shoe_size = SelectField('Shoes size', validators=[DataRequired()], 
                          choices=[(str(i), str(i)) for i in range(35, 47)])
    shirt_size = SelectField('Shirt size', validators=[DataRequired()], 
                           choices=[('XS', 'XS'), ('S', 'S'), ('M', 'M'), 
                                   ('L', 'L'), ('XL', 'XL'), ('XXL', 'XXL')])
    
    # Academic details
    specialization = SelectField('Specialization', validators=[DataRequired()], 
                               choices=[('Animal science', 'Animal science'), 
                                       ('Plant science', 'Plant science'),
                                       ('Agriculture engineering', 'Agriculture engineering'),
                                       ('Agronomy', 'Agronomy')])
    secondary_specialization = SelectField('Secondary specialization', validators=[Optional()], 
                                         choices=[('', '-- Select --'),
                                                 ('Agronomy', 'Agronomy'),
                                                 ('Horticulture', 'Horticulture'),
                                                 ('Animal husbandry', 'Animal husbandry')])
    
    # Contact details
    email = StringField('Email', validators=[DataRequired(), Email()])
    
    # Additional details
    smokes = SelectField('Smokes', validators=[DataRequired()], 
                        choices=[('Never', 'Never'), ('Sometimes', 'Sometimes'), 
                                ('Regularly', 'Regularly')])
    
    # Document uploads
    passport_scan = FileField('Scanned passport', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    terms_conditions = FileField('Scanned signed terms and conditions', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    health_statement_menora = FileField('Scanned health statement (MENORA)', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    health_statement_ayalon = FileField('Scanned health statement (AYALON)', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    medical_report = FileField('Scanned doctor\'s medical report', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    info_rights = FileField('Scanned info & rights', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    
    # Submission buttons
    submit_save = SubmitField('Save')
    submit_save_send = SubmitField('Save & Send')
    
    def validate_date_of_birth(self, field):
        if field.data:
            today = date.today()
            age = today.year - field.data.year - ((today.month, today.day) < (field.data.month, field.data.day))
            if age > 29:
                raise ValidationError('Candidate must not be more than 29 years old.')
    
    def validate_passport_expiry_date(self, field):
        if field.data and self.passport_issue_date.data:
            if field.data <= self.passport_issue_date.data:
                raise ValidationError('Expiry date must be after issue date.')

class CandidateSearchForm(FlaskForm):
    country = SelectField('Country', choices=[('All countries', 'All countries'), ('Philippines', 'Philippines')])
    university = SelectField('University', choices=[('All universities', 'All universities'), 
                                                 ('DILG-E', 'DILG-E'), ('TESDA', 'TESDA')])
    specialization = SelectField('Specialization', choices=[('All specializations', 'All specializations'),
                                                        ('Animal science', 'Animal science'),
                                                        ('Plant science', 'Plant science'),
                                                        ('Agriculture engineering', 'Agriculture engineering'),
                                                        ('Agronomy', 'Agronomy')])
    status = SelectField('Status', choices=[('All statuses', 'All statuses'),
                                         ('Draft', 'Draft'),
                                         ('New', 'New'),
                                         ('Fixed', 'Fixed'),
                                         ('Rejected', 'Rejected'),
                                         ('Approved', 'Approved'),
                                         ('Quit', 'Quit')])
    passport = StringField('Passport')
    submit = SubmitField('Search')

class DocumentUploadForm(FlaskForm):
    document_type = SelectField('Document Type', choices=[(t.name, t.value) for t in DocumentType])
    document = FileField('Document', validators=[
        FileRequired(),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], 'Images and PDF only!')
    ])
    submit = SubmitField('Upload')
