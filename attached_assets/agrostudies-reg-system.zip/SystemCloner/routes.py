import os
from datetime import datetime
from functools import wraps
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash, generate_password_hash
from flask import (
    Blueprint, render_template, redirect, url_for, flash, 
    request, current_app, send_from_directory, jsonify
)
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from models import User, Candidate, Document, DocumentType, CandidateStatus
from forms import LoginForm, CandidateForm, CandidateSearchForm, DocumentUploadForm
from utils import save_document, allowed_file

# Define Blueprints
auth_bp = Blueprint('auth', __name__)
main_bp = Blueprint('main', __name__)
candidate_bp = Blueprint('candidate', __name__)

# Custom decorators
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or current_user.role.name != 'ADMIN':
            flash('You do not have permission to access this page.', 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

# Authentication routes
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember.data)
            user.last_login = datetime.utcnow()
            db.session.commit()
            
            next_page = request.args.get('next')
            return redirect(next_page or url_for('main.index'))
        else:
            flash('Login unsuccessful. Please check email and password.', 'danger')
    
    return render_template('login.html', form=form)

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

# Main routes
@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/contact')
@login_required
def contact():
    return render_template('contact.html')

@main_bp.route('/help')
@login_required
def help():
    return render_template('help.html')

# Candidate routes
@candidate_bp.route('/candidates')
@login_required
def candidates():
    form = CandidateSearchForm(request.args)
    
    # Base query
    query = Candidate.query
    
    # Apply filters
    if form.country.data and form.country.data != 'All countries':
        query = query.filter(Candidate.country_of_birth == form.country.data)
    
    if form.university.data and form.university.data != 'All universities':
        query = query.filter(Candidate.university == form.university.data)
    
    if form.specialization.data and form.specialization.data != 'All specializations':
        query = query.filter(Candidate.specialization == form.specialization.data)
    
    if form.status.data and form.status.data != 'All statuses':
        query = query.filter(Candidate.status == CandidateStatus[form.status.data])
    
    if form.passport.data:
        query = query.filter(Candidate.passport_number.ilike(f'%{form.passport.data}%'))
    
    # Get candidates with applied filters
    candidates = query.all()
    
    return render_template('candidates.html', 
                          candidates=candidates, 
                          form=form,
                          CandidateStatus=CandidateStatus)

@candidate_bp.route('/candidates/add', methods=['GET', 'POST'])
@login_required
def add_candidate():
    form = CandidateForm()
    
    if form.validate_on_submit():
        try:
            # Create new candidate
            candidate = Candidate(
                university=form.university.data,
                passport_number=form.passport_number.data,
                passport_issue_date=form.passport_issue_date.data,
                passport_expiry_date=form.passport_expiry_date.data,
                first_name=form.first_name.data,
                surname=form.surname.data,
                father_name=form.father_name.data,
                mother_name=form.mother_name.data,
                date_of_birth=form.date_of_birth.data,
                country_of_birth=form.country_of_birth.data,
                nationality=form.nationality.data,
                religion=form.religion.data,
                family_status=form.family_status.data,
                gender=form.gender.data,
                shoe_size=form.shoe_size.data,
                shirt_size=form.shirt_size.data,
                specialization=form.specialization.data,
                secondary_specialization=form.secondary_specialization.data,
                email=form.email.data,
                smokes=form.smokes.data,
                status=CandidateStatus.DRAFT,
                user_id=current_user.id
            )
            
            db.session.add(candidate)
            db.session.flush()  # Get the ID without committing
            
            # Handle document uploads
            documents = [
                (form.passport_scan.data, DocumentType.PASSPORT),
                (form.terms_conditions.data, DocumentType.TERMS_CONDITIONS),
                (form.health_statement_menora.data, DocumentType.HEALTH_MENORA),
                (form.health_statement_ayalon.data, DocumentType.HEALTH_AYALON),
                (form.medical_report.data, DocumentType.MEDICAL_REPORT),
                (form.info_rights.data, DocumentType.INFO_RIGHTS)
            ]
            
            for file, doc_type in documents:
                if file:
                    file_path = save_document(file, candidate.id)
                    document = Document(
                        type=doc_type,
                        filename=secure_filename(file.filename),
                        file_path=file_path,
                        candidate_id=candidate.id
                    )
                    db.session.add(document)
            
            # Submit status based on which button was clicked
            if form.submit_save_send.data:
                candidate.status = CandidateStatus.NEW
                flash('Candidate saved and submitted for review.', 'success')
            else:
                flash('Candidate saved as draft.', 'success')
            
            db.session.commit()
            return redirect(url_for('candidate.candidates'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error adding candidate: {str(e)}', 'danger')
    
    return render_template('registration_form.html', form=form, mode='add')

@candidate_bp.route('/candidates/<int:id>/edit', methods=['GET', 'POST'])
@login_required
def edit_candidate(id):
    candidate = Candidate.query.get_or_404(id)
    
    # Check if user has permission to edit this candidate
    if current_user.role.name != 'ADMIN' and candidate.user_id != current_user.id:
        flash('You do not have permission to edit this candidate.', 'danger')
        return redirect(url_for('candidate.candidates'))
    
    # Check if candidate's status allows editing
    if candidate.status not in [CandidateStatus.DRAFT, CandidateStatus.REJECTED]:
        flash('This candidate cannot be edited in their current status.', 'warning')
        return redirect(url_for('candidate.candidates'))
    
    form = CandidateForm(obj=candidate)
    
    if form.validate_on_submit():
        try:
            # Update candidate details
            candidate.university = form.university.data
            candidate.passport_number = form.passport_number.data
            candidate.passport_issue_date = form.passport_issue_date.data
            candidate.passport_expiry_date = form.passport_expiry_date.data
            candidate.first_name = form.first_name.data
            candidate.surname = form.surname.data
            candidate.father_name = form.father_name.data
            candidate.mother_name = form.mother_name.data
            candidate.date_of_birth = form.date_of_birth.data
            candidate.country_of_birth = form.country_of_birth.data
            candidate.nationality = form.nationality.data
            candidate.religion = form.religion.data
            candidate.family_status = form.family_status.data
            candidate.gender = form.gender.data
            candidate.shoe_size = form.shoe_size.data
            candidate.shirt_size = form.shirt_size.data
            candidate.specialization = form.specialization.data
            candidate.secondary_specialization = form.secondary_specialization.data
            candidate.email = form.email.data
            candidate.smokes = form.smokes.data
            
            # Handle document uploads (only if new files are provided)
            document_fields = [
                (form.passport_scan.data, DocumentType.PASSPORT),
                (form.terms_conditions.data, DocumentType.TERMS_CONDITIONS),
                (form.health_statement_menora.data, DocumentType.HEALTH_MENORA),
                (form.health_statement_ayalon.data, DocumentType.HEALTH_AYALON),
                (form.medical_report.data, DocumentType.MEDICAL_REPORT),
                (form.info_rights.data, DocumentType.INFO_RIGHTS)
            ]
            
            for file, doc_type in document_fields:
                if file and file.filename:
                    # Check if document of this type already exists
                    existing_doc = Document.query.filter_by(
                        candidate_id=candidate.id, 
                        type=doc_type
                    ).first()
                    
                    if existing_doc:
                        # Delete the old file
                        try:
                            os.remove(existing_doc.file_path)
                        except:
                            pass
                        
                        # Update with new file
                        file_path = save_document(file, candidate.id)
                        existing_doc.filename = secure_filename(file.filename)
                        existing_doc.file_path = file_path
                        existing_doc.upload_date = datetime.utcnow()
                    else:
                        # Create new document entry
                        file_path = save_document(file, candidate.id)
                        document = Document(
                            type=doc_type,
                            filename=secure_filename(file.filename),
                            file_path=file_path,
                            candidate_id=candidate.id
                        )
                        db.session.add(document)
            
            # Submit status based on which button was clicked
            if form.submit_save_send.data:
                if candidate.status == CandidateStatus.REJECTED:
                    candidate.status = CandidateStatus.FIXED
                else:
                    candidate.status = CandidateStatus.NEW
                flash('Candidate updated and submitted for review.', 'success')
            else:
                candidate.status = CandidateStatus.DRAFT
                flash('Candidate updated and saved as draft.', 'success')
            
            candidate.updated_at = datetime.utcnow()
            db.session.commit()
            return redirect(url_for('candidate.candidates'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error updating candidate: {str(e)}', 'danger')
    
    # Initialize form with existing documents
    return render_template('registration_form.html', form=form, candidate=candidate, mode='edit')

@candidate_bp.route('/candidates/<int:id>/view')
@login_required
def view_candidate(id):
    candidate = Candidate.query.get_or_404(id)
    documents = Document.query.filter_by(candidate_id=candidate.id).all()
    
    return render_template('registration_form.html', 
                          candidate=candidate, 
                          documents=documents, 
                          mode='view')

@candidate_bp.route('/candidates/<int:id>/delete', methods=['POST'])
@login_required
def delete_candidate(id):
    candidate = Candidate.query.get_or_404(id)
    
    # Check if user has permission to delete this candidate
    if current_user.role.name != 'ADMIN' and candidate.user_id != current_user.id:
        flash('You do not have permission to delete this candidate.', 'danger')
        return redirect(url_for('candidate.candidates'))
    
    try:
        # Delete associated documents
        documents = Document.query.filter_by(candidate_id=candidate.id).all()
        for doc in documents:
            try:
                os.remove(doc.file_path)
            except:
                pass
            db.session.delete(doc)
        
        # Delete the candidate
        db.session.delete(candidate)
        db.session.commit()
        flash('Candidate deleted successfully.', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting candidate: {str(e)}', 'danger')
    
    return redirect(url_for('candidate.candidates'))

@candidate_bp.route('/candidates/<int:id>/status/<status>', methods=['POST'])
@login_required
@admin_required
def update_status(id, status):
    candidate = Candidate.query.get_or_404(id)
    
    try:
        if status in [s.name for s in CandidateStatus]:
            candidate.status = CandidateStatus[status]
            candidate.updated_at = datetime.utcnow()
            db.session.commit()
            flash(f'Candidate status updated to {status}.', 'success')
        else:
            flash('Invalid status.', 'danger')
    except Exception as e:
        db.session.rollback()
        flash(f'Error updating status: {str(e)}', 'danger')
    
    return redirect(url_for('candidate.candidates'))

@candidate_bp.route('/documents/<int:id>')
@login_required
def view_document(id):
    document = Document.query.get_or_404(id)
    candidate = Candidate.query.get_or_404(document.candidate_id)
    
    # Check if user has permission to view this document
    if current_user.role.name != 'ADMIN' and candidate.user_id != current_user.id:
        flash('You do not have permission to view this document.', 'danger')
        return redirect(url_for('candidate.candidates'))
    
    directory = os.path.dirname(document.file_path)
    filename = os.path.basename(document.file_path)
    
    return send_from_directory(directory, filename)
