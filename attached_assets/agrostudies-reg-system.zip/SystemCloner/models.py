import enum
from datetime import datetime
from app import db, login_manager
from flask_login import UserMixin
from sqlalchemy.ext.hybrid import hybrid_property
from sqlalchemy import Enum, func, Column

class UserRole(enum.Enum):
    ADMIN = 'admin'
    COORDINATOR = 'coordinator'

class CandidateStatus(enum.Enum):
    DRAFT = 'Draft'
    NEW = 'New'
    FIXED = 'Fixed'
    REJECTED = 'Rejected'
    APPROVED = 'Approved'
    QUIT = 'Quit'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(Enum(UserRole), nullable=False, default=UserRole.COORDINATOR)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # Relationship with candidates they manage
    candidates = db.relationship('Candidate', backref='coordinator', lazy=True)
    
    def __repr__(self):
        return f'<User {self.email}>'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class Candidate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    # Passport details
    passport_number = db.Column(db.String(20), unique=True, nullable=False)
    passport_issue_date = db.Column(db.Date, nullable=True)
    passport_expiry_date = db.Column(db.Date, nullable=True)
    
    # Personal details
    first_name = db.Column(db.String(50), nullable=False)
    surname = db.Column(db.String(50), nullable=False)
    father_name = db.Column(db.String(100), nullable=True)
    mother_name = db.Column(db.String(100), nullable=True)
    date_of_birth = db.Column(db.Date, nullable=True)
    country_of_birth = db.Column(db.String(50), nullable=True)
    nationality = db.Column(db.String(50), nullable=True)
    religion = db.Column(db.String(50), nullable=True)
    family_status = db.Column(db.String(20), nullable=True)
    gender = db.Column(db.String(10), nullable=True)
    
    # Academic details
    university = db.Column(db.String(100), nullable=False)
    specialization = db.Column(db.String(100), nullable=True)
    secondary_specialization = db.Column(db.String(100), nullable=True)
    
    # Contact details
    email = db.Column(db.String(120), nullable=True)
    
    # Additional details
    smokes = db.Column(db.String(10), nullable=True)
    shoe_size = db.Column(db.String(10), nullable=True)
    shirt_size = db.Column(db.String(10), nullable=True)
    
    # Status and tracking
    status = db.Column(Enum(CandidateStatus), nullable=False, default=CandidateStatus.DRAFT)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # User who created/manages this candidate
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Documents
    documents = db.relationship('Document', backref='candidate', lazy=True, cascade="all, delete-orphan")
    
    @hybrid_property
    def full_name(self):
        return f"{self.first_name} {self.surname}"
    
    @hybrid_property
    def age(self):
        today = datetime.today().date()
        if self.date_of_birth:
            return today.year - self.date_of_birth.year - ((today.month, today.day) < (self.date_of_birth.month, self.date_of_birth.day))
        return None
    
    def __repr__(self):
        return f'<Candidate {self.passport_number} - {self.full_name}>'

class DocumentType(enum.Enum):
    PASSPORT = 'Scanned passport'
    TERMS_CONDITIONS = 'Scanned signed terms and conditions'
    HEALTH_MENORA = 'Scanned health statement (MENORA)'
    HEALTH_AYALON = 'Scanned health statement (AYALON)'
    MEDICAL_REPORT = 'Scanned doctor\'s medical report'
    INFO_RIGHTS = 'Scanned info & rights'
    FLIGHT_TICKET = 'Flight ticket'

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(Enum(DocumentType), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    file_path = db.Column(db.String(255), nullable=False)
    
    # Candidate to whom this document belongs
    candidate_id = db.Column(db.Integer, db.ForeignKey('candidate.id'), nullable=False)
    
    def __repr__(self):
        return f'<Document {self.type.value} for Candidate {self.candidate_id}>'
