import os
import shutil
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash
from app import create_app, db
from models import User, Candidate, Document, DocumentType, CandidateStatus, UserRole

def create_sample_candidates():
    app = create_app()
    
    with app.app_context():
        # Check if we already have sample candidates
        if Candidate.query.count() > 0:
            print("Sample candidates already exist. Skipping creation.")
            return
        
        # Ensure we have a coordinator user
        coord = User.query.filter_by(email='coordinator@agrostudies.com').first()
        if not coord:
            coord = User(
                name='Coordinator',
                email='coordinator@agrostudies.com',
                password_hash=generate_password_hash('coordinator123'),
                role=UserRole.COORDINATOR
            )
            db.session.add(coord)
            db.session.commit()
        
        # Create upload directory if it doesn't exist
        upload_dir = os.path.join(os.getcwd(), 'uploads')
        os.makedirs(upload_dir, exist_ok=True)
        
        # Sample document file paths
        sample_docs = {
            DocumentType.PASSPORT: 'uploads/sample_docs/passport.jpg',
            DocumentType.TERMS_CONDITIONS: 'uploads/sample_docs/terms.jpg',
            DocumentType.HEALTH_MENORA: 'uploads/sample_docs/health_menora.jpg',
            DocumentType.HEALTH_AYALON: 'uploads/sample_docs/health_ayalon.jpg',
            DocumentType.MEDICAL_REPORT: 'uploads/sample_docs/medical_report.jpg',
            DocumentType.INFO_RIGHTS: 'uploads/sample_docs/info_rights.jpg'
        }
        
        # Common candidate data
        today = datetime.utcnow()
        birthdate = today - timedelta(days=365 * 25)  # 25 years old
        passport_issue = today - timedelta(days=365)  # 1 year ago
        passport_expiry = today + timedelta(days=365 * 4)  # 4 years from now
        
        # Create candidates with different statuses
        candidates_data = [
            {
                "first_name": "Juan", 
                "surname": "Garcia",
                "passport_number": "PH1234567",
                "status": CandidateStatus.DRAFT
            },
            {
                "first_name": "Maria", 
                "surname": "Santos",
                "passport_number": "PH2345678",
                "status": CandidateStatus.NEW
            },
            {
                "first_name": "Pedro", 
                "surname": "Reyes",
                "passport_number": "PH3456789",
                "status": CandidateStatus.APPROVED
            },
            {
                "first_name": "Sofia", 
                "surname": "Cruz",
                "passport_number": "PH4567890",
                "status": CandidateStatus.REJECTED
            }
        ]
        
        for idx, data in enumerate(candidates_data):
            # Create candidate
            candidate = Candidate(
                university="TESDA" if idx % 2 == 0 else "DILG-E",
                passport_number=data["passport_number"],
                passport_issue_date=passport_issue,
                passport_expiry_date=passport_expiry,
                first_name=data["first_name"],
                surname=data["surname"],
                father_name=f"Father of {data['first_name']}",
                mother_name=f"Mother of {data['first_name']}",
                date_of_birth=birthdate,
                country_of_birth="Philippines",
                nationality="Filipino",
                religion="Catholic",
                family_status="Single",
                gender="Male" if idx % 2 == 0 else "Female",
                shoe_size="40" if idx % 2 == 0 else "38",
                shirt_size="M" if idx % 2 == 0 else "S",
                specialization="Animal science" if idx % 2 == 0 else "Plant science",
                secondary_specialization="Horticulture" if idx % 2 == 0 else "Agronomy",
                email=f"{data['first_name'].lower()}.{data['surname'].lower()}@example.com",
                smokes="Never",
                status=data["status"],
                user_id=coord.id,
                created_at=today - timedelta(days=10-idx),
                updated_at=today - timedelta(days=5-idx)
            )
            
            db.session.add(candidate)
            db.session.flush()  # Get the ID without committing
            
            # Add documents
            candidate_upload_dir = os.path.join(upload_dir, f'candidate_{candidate.id}')
            os.makedirs(candidate_upload_dir, exist_ok=True)
            
            for doc_type, sample_path in sample_docs.items():
                if os.path.exists(sample_path):
                    # Create destination filename
                    filename = f"{doc_type.value.lower().replace(' ', '_')}_{candidate.id}.jpg"
                    dest_path = os.path.join(candidate_upload_dir, filename)
                    
                    # Copy the sample file
                    shutil.copy(sample_path, dest_path)
                    
                    # Create document record
                    document = Document(
                        type=doc_type,
                        filename=filename,
                        file_path=dest_path,
                        candidate_id=candidate.id
                    )
                    db.session.add(document)
        
        # Commit all changes
        db.session.commit()
        print(f"Created {len(candidates_data)} sample candidates with different statuses.")

if __name__ == "__main__":
    create_sample_candidates()