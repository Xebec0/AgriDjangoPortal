from app import create_app, db
from models import User, UserRole
from werkzeug.security import generate_password_hash
from datetime import datetime

def create_admin_user():
    app = create_app()
    with app.app_context():
        # Check if admin already exists
        admin_user = User.query.filter_by(email='admin@agrostudies.com').first()
        coordinator_user = User.query.filter_by(email='coordinator@agrostudies.com').first()
        
        if not admin_user:
            # Create admin user
            admin = User(
                name='Administrator',
                email='admin@agrostudies.com',
                password_hash=generate_password_hash('admin123'),
                role=UserRole.ADMIN,
                created_at=datetime.utcnow()
            )
            db.session.add(admin)
            print("Admin user created successfully.")
            print("Admin email: admin@agrostudies.com, Password: admin123")
        else:
            print("Admin user already exists.")
        
        if not coordinator_user:
            # Create coordinator user
            coordinator = User(
                name='Coordinator',
                email='coordinator@agrostudies.com',
                password_hash=generate_password_hash('coordinator123'),
                role=UserRole.COORDINATOR,
                created_at=datetime.utcnow()
            )
            db.session.add(coordinator)
            print("Coordinator user created successfully.")
            print("Coordinator email: coordinator@agrostudies.com, Password: coordinator123")
        else:
            print("Coordinator user already exists.")
        
        db.session.commit()
            
if __name__ == "__main__":
    create_admin_user()